Codigo para o curso Cypress Discorevy da QA Ninja.

Projeto Buger Eats

Atualizado até aula 19 - Factory e Faker com dados e CPF dinâmicos

Atualizado até aula 15 - Trabalhando com Fixtures

Dependências instaladas:
Aula 7 - Upload de arquivos:
npm install cypress-file-upload --save-dev

Aula 19 - Faker:
npm install faker --save-dev (ou npm install faker@5.5.3 --save-dev)
Validador CPF:
npm install gerador-validador-cpf --save-dev